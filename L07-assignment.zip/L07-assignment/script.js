class Animal {
    constructor(animalName, animalFood) {
        this .speed = 0;
        this.food = animalFood;
        this.name = animalName;
    }
}

class Wabbit extends Animal {
    constructor(name, food) {
        super('Buggsy', 'Cawwots');
    }

    hide() {
        let wabbitStwing = "A Wabbit is named " + this.name + " and he likes to eat " + this.food + ". He is hiding right now because he is afraid of the big bad Andwew.";
        alert(wabbitStwing);
        console.log(wabbitStwing);
    }
}

class Cow extends Animal {
    constructor(name, food) {
        super('Bettsy', 'Weed');
    }

    moo() {
        let cowStwing = "A Cow is named " + this.name + " and she likes to eat " + this.food + " while she moos at Andwew.";
        alert(cowStwing);
        console.log(cowStwing);
    }
}

class Alligator extends Animal {
    constructor(name, food) {
        super('Aly', 'childerens dreams of growing up and have a future with legs');
    }

    eat() {
        let alligatorString = "A Alligator is named " + this.name + " and she is eating right now. Her favorite food is " + this.food + ".";
        alert(alligatorString);
        console.log(alligatorString)
    }
}

class Sloth extends Animal {
    constructor(name, food) {
        super('Sidney', 'boogers');
    }

    sleep() {
        let slothString = "All male Sloths are named " + this.name + ". They will only eat there own " + this.food + ". And they spend over 97 percent of there life asleep."
        alert(slothString);
        console.log(slothString);
    }
}

let wabbitMethod = new Wabbit();
wabbitMethod.hide();

let cowMethod = new Cow();
cowMethod.moo();

let alligatorMethod = new Alligator();
alligatorMethod.eat();

let slothMethod = new Sloth();
slothMethod.sleep();